package com.example.aplikasi_sederhana

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
